package MM0118A07N.Portal.CSP;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.springframework.security.test.web.servlet.request.SecurityMockMvcRequestPostProcessors.csrf;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import MM0118A07N.Portal.CSP.config.JPAConfig;
import MM0118A07N.Portal.CSP.config.SecurityConfig;
import MM0118A07N.Portal.CSP.config.WebMvcConfig;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes={WebMvcConfig.class, JPAConfig.class, SecurityConfig.class})
@WebAppConfiguration
public class AppTest {
	
	private MockMvc mockMvc;

	@Autowired
    private WebApplicationContext context;

    @BeforeEach
    public void setup() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(context).apply(springSecurity()).build();
    }

    @Test
    @WithMockUser(username = "Admin2", roles={"VIEW_CAR"})
    public void testGetCar() throws Exception {
        this.mockMvc.perform(MockMvcRequestBuilders.get("/car"))
                .andDo(print()).andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "User1", roles={"POST_CAR"})
    public void testPostCar() throws Exception {
        this.mockMvc.perform(MockMvcRequestBuilders
                                    .post("/car")
                                    .param("carbrand", "Honda ")
                                    .param("carmodel", "Freddy")
                                    .param("caryear", "2012")
                                    .param("carprice", "$3000")
                                    .param("carcolor", "Black")
                                    .param("carlicenseplate", "2F/4456")
                                    .param("caruploader", "Black Smith")
                                    .param("cardetails", "Smooth")
                                    .with(csrf()))
                    .andDo(print()).andExpect(status().isOk());
       
    }


	@Test
    @WithMockUser(username = "User2", roles={"VIEW_CAR"})
    public void testPostCarWithNoPermission() throws Exception {
        this.mockMvc.perform(MockMvcRequestBuilders
                 .post("/car")
                 .param("carbrand", "BMW ")
                 .param("carmodel", "Mini")
                 .param("caryear", "2012")
                 .param("carprice", "$3000")
                 .param("carcolor", "yellow")
                 .param("carlicenseplate", "2F/55556")
                 .param("caruploader", "Black Smith")
                 .param("cardetails", "Smooth")
                .with(csrf()))
                .andDo(print()).andExpect(status().is4xxClientError());
    }

}
