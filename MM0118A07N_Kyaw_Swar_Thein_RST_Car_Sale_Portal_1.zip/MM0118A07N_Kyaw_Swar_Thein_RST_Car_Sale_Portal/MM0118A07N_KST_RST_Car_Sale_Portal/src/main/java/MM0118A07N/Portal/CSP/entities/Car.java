package MM0118A07N.Portal.CSP.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;


@Entity
@Table(name="kst_car")
public class Car {
	 @Id
	    @Column(name="id")
	    @GeneratedValue(strategy= GenerationType.IDENTITY)
	    private Long id;

	 	@Column(name="carbrand")
	    private String carbrand;
 
	    @Column(name="carmodel")
	    private String carmodel;

	    @Column(name="caryear")
	    private String caryear;
	    
	    @Column(name="carprice")
	    private String carprice;

	    @Column(name="carcolor")
	    private String carcolor;
	    
	    @Column(name="carlicenseplate")
	    private String carlicenseplate;
	    
	    @Column(name="carmake")
	    private String carmake;
	    
	    
		@Column(name="caruploader")
	    private String caruploader;
	    
	    @Column(name="cardetails")
	    private String cardetails;


	    @OneToMany(mappedBy = "car", orphanRemoval=true)
	    private Set<BidCar> bids = new HashSet<BidCar>();

	    public Long getId() {
	        return id;
	    }

	    public void setId(Long id) {
	        this.id = id;
	    }
	    
	    
	    public String getCarbrand() {
			return carbrand;
		}

		public void setCarbrand(String carbrand) {
			this.carbrand = carbrand;
		}
	    
	    

		public String getCarmodel() {
			return carmodel;
		}

		public void setCarmodel(String carmodel) {
			this.carmodel = carmodel;
		}

		

		public String getCaryear() {
			return caryear;
		}

		public void setCaryear(String caryear) {
			this.caryear = caryear;
		}
		
		
		
		public String getCarprice() {
			return carprice;
		}

		public void setCarprice(String carprice) {
			this.carprice = carprice;
		}
		
		
		
		public String getCarcolor() {
			return carcolor;
		}

		public void setCarcolor(String carcolor) {
			this.carcolor = carcolor;
		}

		
		
		public String getCarlicenseplate() {
			return carlicenseplate;
		}

		public void setCarlicenseplate(String carlicenseplate) {
			this.carlicenseplate = carlicenseplate;
		}
		
		
		
		public String getCarmake() {
			return carmake;
		}

		public void setCarmake(String carmake) {
			this.carmake = carmake;
		}

		

		public String getCaruploader() {
			return caruploader;
		}

		public void setCaruploader(String caruploader) {
			this.caruploader = caruploader;
		}
		
		
		

		public String getCardetails() {
			return cardetails;
		}

		public void setCardetails(String cardetails) {
			this.cardetails = cardetails;
		}

				

		public Set<BidCar> getBids() {
			return bids;
		}

		public void setBids(Set<BidCar> bids) {
			this.bids = bids;
		}

		    

}

