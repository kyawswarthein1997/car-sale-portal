package MM0118A07N.Portal.CSP.Controller;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import MM0118A07N.Portal.CSP.entities.Car;
import MM0118A07N.Portal.CSP.services.CarService;

@Controller
public class CarController {
	 private static Logger logger = LoggerFactory.getLogger(CarController.class);

	    @Autowired
	    private CarService carService;

	    @RequestMapping(value="/",  method= RequestMethod.GET)
	    public String handleRootRequest(Model model) {
	        return "redirect:car";//jsp file
	    }

	    @RequestMapping(value="car",  method= RequestMethod.GET)
	    public String viewCar(Model model) {
	        List<Car> car = carService.getAllCar();
	        if(!CollectionUtils.isEmpty(car)) {
	            model.addAttribute("car", car);
	        }
	        return "welcome";
	    }

	    @RequestMapping(value="car",  method = {RequestMethod.POST, RequestMethod.PUT})
	    public String saveStore(@RequestParam(value="id", required = false) Long id,
	    						@RequestParam("carbrand") String carbrand,
	                            @RequestParam("carmodel") String carmodel,
	                            @RequestParam("caryear") String caryear,
	                            @RequestParam("carprice") String carprice,
	                            @RequestParam("carcolor") String carcolor,
	                            @RequestParam("carlicenseplate") String carlicenseplate,
	                            @RequestParam("carmake") String carmake,
	                            @RequestParam("caruploader") String caruploader,
	                            @RequestParam("cardetails") String cardetails,
	                            @RequestParam(value="address", required=false) String address,
	                            @RequestParam(value="category_id", required=false) Integer category_id,
	                            @RequestParam(value="category_name", required=false) String categoryName,
	                            Model model) {
	        Car car = new Car();
	        car.setId(id != null ? id: 0);
	        car.setCarbrand(carbrand);
	        car.setCarmodel(carmodel);
	        car.setCaryear(caryear);
	        car.setCarprice(carprice);
	        car.setCarcolor(carcolor);
	        car.setCarlicenseplate(carlicenseplate);
	        car.setCarmake(carmake);
	        car.setCaruploader(caruploader);
	        car.setCardetails(cardetails);

	       // logger.debug("Store name:{}, phone_number: {}", store.getName(), store.getPhoneNumber());
	        Car savedCar = carService.saveCar(car);
	        model.addAttribute("car", carService.getAllCar());
	        return "welcome";
	    }
	    
	    
	    @RequestMapping("/search")
		public ModelAndView search(@RequestParam String keyword) {
			List<Car> result = carService.search(keyword);
			ModelAndView mav = new ModelAndView("search");
			mav.addObject("result", result);
		return mav;
		}

		public static Logger getLogger() {
			return logger;
		}

		public static void setLogger(Logger logger) {
			CarController.logger = logger;
		}
}