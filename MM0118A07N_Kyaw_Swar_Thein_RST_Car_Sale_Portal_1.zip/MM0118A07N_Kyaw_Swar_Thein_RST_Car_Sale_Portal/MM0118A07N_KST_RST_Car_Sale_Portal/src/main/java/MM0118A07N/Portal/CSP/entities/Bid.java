package MM0118A07N.Portal.CSP.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="kst_bid")
public class Bid {
	@Id
    @Column(name="id")
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Long id;

    @Column(name="bidprice")
    private int bidprice;

    public int getBidprice() {
		return bidprice;
	}

	public void setBidprice(int bidprice) {
		this.bidprice = bidprice;
	}

	public String getRequestdrive() {
		return requestdrive;
	}

	public void setRequestdrive(String requestdrive) {
		this.requestdrive = requestdrive;
	}

	@Column(name="requestdrive")
    private String requestdrive;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
