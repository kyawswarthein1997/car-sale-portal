package MM0118A07N.Portal.CSP.daos;

import org.springframework.data.jpa.repository.JpaRepository;

import MM0118A07N.Portal.CSP.entities.User;

public interface UserRepository extends JpaRepository<User, Long>{
	User findByUserName(String name);
}
