package MM0118A07N.Portal.CSP.Controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import MM0118A07N.Portal.CSP.entities.User;
import MM0118A07N.Portal.CSP.services.UserService;


@Controller
public class LoginController {

	@Autowired
	private UserService userService;
	
	
    @RequestMapping(value="/login",  method= RequestMethod.GET)
    public String onLogin() {
        return "login";//call jsp file, same with jsp file name
    }

    @RequestMapping(value="/login_error")
    public String onLoginError(Model model) {
        String error_msg = "Incorrect user or password. Please re-enter or Invalid Users.";
        model.addAttribute("error_string", error_msg);
        return "login";//cal jsp file, same with jsp file name
    }
    
    @RequestMapping(value="/register")
	public String newUserForm(Map<String, Object> model) {
		User user = new User();
		model.put("user", user);
		return "register";
	}
    
	@RequestMapping(value = "/save", method = RequestMethod.POST)
	public String saveUser(@ModelAttribute("user") User user) {
		System.out.println("/save Login Controller");
		userService.save(user);
		String register_success = "Your registeration is successful. Please login to our portal.";
		return "thank";
	}
	
//	@RequestMapping(value = "/admin", method = RequestMethod.GET)
//	public String adminPage(ModelMap model) {
//		model.addAttribute("user", getPrincipal());
//		return "admin";
//	}
//	
//	@RequestMapping(value = "/Access_Denied", method = RequestMethod.GET)
//	public String accessDeniedPage(ModelMap model) {
//		model.addAttribute("user", getPrincipal());
//		return "accessDenied";
//	}
//
//	private String getPrincipal(){
//		String userName = null;
//		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
//
//		if (principal instanceof UserDetails) {
//			userName = ((UserDetails)principal).getUsername();
//		} else {
//			userName = principal.toString();
//		}
//		return userName;
//	}
	
}

