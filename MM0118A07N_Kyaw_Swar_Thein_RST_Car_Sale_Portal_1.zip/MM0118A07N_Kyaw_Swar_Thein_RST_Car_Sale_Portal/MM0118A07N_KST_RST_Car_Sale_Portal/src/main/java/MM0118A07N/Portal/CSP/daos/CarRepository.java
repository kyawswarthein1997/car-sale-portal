package MM0118A07N.Portal.CSP.daos;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import MM0118A07N.Portal.CSP.entities.Car;


public interface CarRepository extends JpaRepository<Car, Long> {
	Optional<Car> findBycarmodel(String carmodel);
	Optional<Car> findBycarbrand(String carbrand);
	Optional<Car> findBycaryear(String caryear);
	Optional<Car> findBycarprice(String carprice);
	Optional<Car> findBycarcolor(String carcolor);
	Optional<Car> findBycarlicenseplate(String carlicenseplate);
	Optional<Car> findBycarmake(String carmake);
	Optional<Car> findBycaruploader(String caruploader);
	Optional<Car> findBycardetails(String cardetails);
	@Query(value = "SELECT c FROM Car c WHERE c.carbrand LIKE '%' || :keyword || '%'"
			+ " OR c.carmodel LIKE '%' || :keyword || '%'"
			+ " OR c.caryear LIKE '%' || :keyword || '%'"
			+ " OR c.carprice LIKE '%' || :keyword || '%'"
			+ " OR c.carcolor LIKE '%' || :keyword || '%'"
			+ " OR c.carlicenseplate LIKE '%' || :keyword || '%'"
			+ " OR c.carmake LIKE '%' || :keyword || '%'"
			+ " OR c.caruploader LIKE '%' || :keyword || '%'"
			+ " OR c.cardetails LIKE '%' || :keyword || '%'")
			public List<Car> search(@Param("keyword") String keyword);
	
	
}
