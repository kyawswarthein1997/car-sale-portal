package MM0118A07N.Portal.CSP.services;

import java.util.HashSet;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import MM0118A07N.Portal.CSP.daos.RoleRepository;
import MM0118A07N.Portal.CSP.daos.UserRepository;
import MM0118A07N.Portal.CSP.entities.User;

@Service
@Transactional
public class UserService {
	@Autowired
	UserRepository repo;

	@Autowired
    private RoleRepository roleRepository;
	
	public void save(User user) {		
		System.out.println("----------------------------------"+roleRepository.findAll());
		user.setRoles(new HashSet<>(roleRepository.findBySpecificRoles("POST_CAR")));
        repo.save(user);	
	}

	public List<User> listAll() {
		return (List<User>) repo.findAll();
	}

	public User get(Long id) {
		return repo.findById(id).get();
	}

	public void delete(Long id) {
		repo.deleteById(id);
	}
	
}
