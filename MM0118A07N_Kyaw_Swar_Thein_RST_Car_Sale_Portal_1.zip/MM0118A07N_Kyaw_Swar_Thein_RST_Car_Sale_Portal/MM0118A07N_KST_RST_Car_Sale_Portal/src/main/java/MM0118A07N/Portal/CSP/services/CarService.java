package MM0118A07N.Portal.CSP.services;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import MM0118A07N.Portal.CSP.Controller.CarController;
import MM0118A07N.Portal.CSP.daos.CarRepository;
import MM0118A07N.Portal.CSP.entities.Car;


@Service
@Transactional
public class CarService {
	private static final Logger logger = LoggerFactory.getLogger(CarController.class);

    @Autowired
    private CarRepository carRepository;

    public List<Car> getAllCar() {
        return carRepository.findAll();
    }
    public Optional<Car> findStoreBycarbrand(String carbrand) {
        return carRepository.findBycarbrand(carbrand);
    }
    public Optional<Car> findStoreBycarmodel(String carmodel) {
        return carRepository.findBycarmodel(carmodel);
    }
    public Optional<Car> findStoreBycaryear(String caryear) {
        return carRepository.findBycaryear(caryear);
    }
    public Optional<Car> findStoreBycarprice(String carprice) {
        return carRepository.findBycarprice(carprice);
    }
    public Optional<Car> findStoreBycarcolor(String carcolor) {
        return carRepository.findBycarcolor(carcolor);
    }
    public Optional<Car> findStoreBycarlicenseplate(String carlicenseplate) {
        return carRepository.findBycarlicenseplate(carlicenseplate);
    }
    public Optional<Car> findStoreBycaruploader(String caruploader) {
        return carRepository.findBycaruploader(caruploader);
    }
    public Optional<Car> findStoreBycarmake(String carmake) {
        return carRepository.findBycarmake(carmake);
    }
    public Optional<Car> findStoreBycardetails(String cardetails) {
        return carRepository.findBycardetails(cardetails);
    }
//used for both update and Save user
    public Car saveCar(Car car) {
        Car dbCar= car;
        if (car.getId() > 0) {
            Optional<Car>  tmpStore = carRepository.findById(car.getId());
            if(tmpStore.isPresent()) {
                dbCar = tmpStore.get(); // old object
                dbCar.setCarbrand(car.getCarbrand());
                dbCar.setCarmodel(car.getCarmodel());
                dbCar.setCaryear(car.getCaryear());
                dbCar.setCarprice(car.getCarprice());
                dbCar.setCarcolor(car.getCarcolor());
                dbCar.setCarlicenseplate(car.getCarlicenseplate());
                dbCar.setCarmake(car.getCarmake());
                dbCar.setCaruploader(car.getCaruploader());
                dbCar.setCardetails(car.getCardetails());
            }
        }
        Car savedStore = carRepository.save(dbCar);
        return savedStore;
    }

	public static Logger getLogger() {
		return logger;
	}

public List<Car> search(String keyword) {
		// TODO Auto-generated method stub
	return carRepository.search(keyword);
}

}
