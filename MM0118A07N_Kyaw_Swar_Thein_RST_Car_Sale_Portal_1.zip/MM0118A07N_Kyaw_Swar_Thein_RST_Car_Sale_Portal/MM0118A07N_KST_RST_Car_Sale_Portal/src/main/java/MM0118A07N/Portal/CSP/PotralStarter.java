package MM0118A07N.Portal.CSP;

import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

import MM0118A07N.Portal.CSP.config.JPAConfig;
import MM0118A07N.Portal.CSP.config.SecurityConfig;
import MM0118A07N.Portal.CSP.config.WebMvcConfig;

public class PotralStarter extends AbstractAnnotationConfigDispatcherServletInitializer{

	@Override
	protected Class<?>[] getRootConfigClasses() {
		return new Class[]{JPAConfig.class, SecurityConfig.class};
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		return new Class[]{WebMvcConfig.class};
	}

	@Override
	protected String[] getServletMappings() {
		return new String[]{"/"};
	}

}
