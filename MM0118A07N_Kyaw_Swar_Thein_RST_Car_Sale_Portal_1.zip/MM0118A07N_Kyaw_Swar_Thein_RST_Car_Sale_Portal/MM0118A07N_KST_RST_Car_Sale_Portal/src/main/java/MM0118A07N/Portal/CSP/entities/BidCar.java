package MM0118A07N.Portal.CSP.entities;

import java.time.LocalDateTime;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="bid_car")
public class BidCar {
	 @Id
	    @Column(name="id")
	    @GeneratedValue(strategy= GenerationType.IDENTITY)
	    private Long id;

	    @ManyToOne(fetch = FetchType.EAGER)
	    @JoinColumn(name="car_id")
	    private Car car;

	    @ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	    @JoinColumn(name="bid_id")
	    private Bid bid;

	    @ManyToOne(fetch = FetchType.EAGER)
	    @JoinColumn(name="user_id")
	    private User user;

	    @Column(name="bid_time")
	    private LocalDateTime bidDateTime;

	    public BidCar() {
		}

		public Long getId() {
	        return id;
	    }

	    public void setId(Long id) {
	        this.id = id;
	    }

	    public Car getCar() {
			return car;
		}

		public void setCar(Car car) {
			this.car = car;
		}
		

	    public Bid getBid() {
			return bid;
		}

		public void setBid(Bid bid) {
			this.bid = bid;
		}


	    public User getUser() {
	        return user;
	    }

	    public void setUser(User user) {
	        this.user = user;
	    }

	    public LocalDateTime getBidDateTime() {
			return bidDateTime;
		}

		public void setBidDateTime(LocalDateTime bidDateTime) {
			this.bidDateTime = bidDateTime;
		}

}
